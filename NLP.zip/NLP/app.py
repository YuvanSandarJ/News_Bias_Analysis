# Streamlit OCR and Stance Analysis App

import os
import torch
import torch.nn as nn
import joblib
import numpy as np
import streamlit as st
import tempfile
from transformers import pipeline
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import easyocr
from textblob import TextBlob
from langdetect import detect
from deep_translator import GoogleTranslator
import pickle
from PIL import Image


class StanceModel:
    def __init__(self, input_dim=4, output_dim=3, model_dir="D:/NLP/project/saved_models"):
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.model_dir = model_dir
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = None
        self.tfidf = None
        self.label_encoder = None

    def load(self):
        """Load the trained model, TF-IDF vectorizer, and label encoder."""
        # Load model
        self.model = nn.Sequential(
            nn.Linear(self.input_dim + 5000, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, self.output_dim),
            nn.Softmax(dim=1)
        ).to(self.device)

        self.model.load_state_dict(torch.load(
            os.path.join(self.model_dir, "stance_model.pt"),
            map_location=self.device
        ))

        # Load vectorizer and label encoder
        self.tfidf = joblib.load(os.path.join(self.model_dir, "tfidf_vectorizer.joblib"))
        self.label_encoder = joblib.load(os.path.join(self.model_dir, "label_encoder.joblib"))
        self.model.eval()

    def save(self):
        """Save the model weights and other components to disk."""
        torch.save(self.model.state_dict(), os.path.join(self.model_dir, "stance_model.pt"))
        joblib.dump(self.tfidf, os.path.join(self.model_dir, "tfidf_vectorizer.joblib"))
        joblib.dump(self.label_encoder, os.path.join(self.model_dir, "label_encoder.joblib"))

    def predict(self, features):
        """Predict stance based on input features."""
        with torch.no_grad():
            return self.model(features)


class StanceSummaryModel:
    def __init__(self, stance_model_dir, summarizer_model="facebook/bart-large-cnn"):
        self.stance_model = StanceModel(input_dim=4, output_dim=3, model_dir=stance_model_dir)
        self.stance_model.load()
        self.analyzer = SentimentIntensityAnalyzer()
        self.summarizer = pipeline("summarization", model=summarizer_model)

    def summarize_and_analyze(self, text):
        """Summarize the text and perform stance and sentiment analysis."""
        # Step 1: Summarize the input text
        summary = self.summarizer(text, max_length=150, min_length=50, do_sample=False)[0]['summary_text']

        # Step 2: Sentiment features using VADER
        sentiment_scores = self.analyzer.polarity_scores(summary)
        sentiment_features = np.array([
            sentiment_scores['neg'],
            sentiment_scores['neu'],
            sentiment_scores['pos'],
            sentiment_scores['compound']
        ]).reshape(1, -1)

        # Step 3: TF-IDF + Sentiment
        tfidf_features = self.stance_model.tfidf.transform([summary]).toarray()
        combined_features = np.hstack([tfidf_features, sentiment_features])

        # Step 4: Predict stance
        input_tensor = torch.tensor(combined_features, dtype=torch.float32).to(self.stance_model.device)
        output = self.stance_model.predict(input_tensor)
        stance_index = torch.argmax(output, dim=1).item()

        # Step 5: Bias score (compound sentiment)
        bias_score = sentiment_scores['compound']

        return summary, stance_index, bias_score


# Language mapping for EasyOCR (paired languages for compatibility)
LANGUAGE_MAPPING = {
    'fr': ['fr', 'en'],
    'ja': ['ja', 'en'], 
    'ko': ['ko', 'en'], 
    'ar': ['ar', 'en'],
    'ru': ['ru', 'en'],
    'it': ['it', 'en'],
    'pt': ['pt', 'en'],  
}

class OCRTextModel:
    def __init__(self, languages=None, use_gpu=True):
        if languages is None:
            languages = ['fr']  # Only French for OCR (adjust as needed)
        
        # Prepare a list of language pairs (combinations)
        self.language_pairs = [LANGUAGE_MAPPING[lang] for lang in languages if lang in LANGUAGE_MAPPING]
        
        # Initialize the translator
        self.translator = GoogleTranslator()

        # Initialize OCR model (PyTorch-based, easyocr uses PyTorch internally)
        self.reader = easyocr.Reader(['fr', 'en'], gpu=use_gpu)

    def process_image(self, image_path):
        # Read text from image by processing each language pair individually
        raw_text = ""
        for lang_pair in self.language_pairs:
            results = self.reader.readtext(image_path, detail=0)
            raw_text += " ".join(results) + " "

        if not raw_text.strip():
            raise ValueError("No text detected in image.")

        # Detect language (This should always detect French if the image is in French)
        detected_lang = detect(raw_text)
        st.info(f"🌐 Detected language code: {detected_lang}")

        # If detected language is French, translate it to English
        if detected_lang == 'fr':
            translated_text = self.translator.translate(raw_text, src='fr', target='en')
            st.info(f"🔵 Translated text:\n{translated_text}")
        else:
            translated_text = raw_text
            st.info(f"✅ Text is already in English.")

        # Correct grammar using TextBlob
        corrected_blob = TextBlob(translated_text).correct()
        formatted_text = "\n\n".join([str(sentence) for sentence in corrected_blob.sentences])  # Paragraphs separated by double newline

        return formatted_text, detected_lang


def run_stance_analysis(model_dir, text):
    """Run stance and sentiment analysis on the provided text."""
    stance_summary_model = StanceSummaryModel(stance_model_dir=model_dir)
    summary, stance, bias_score = stance_summary_model.summarize_and_analyze(text)

    stance_labels = ["Political", "Terrorist", "Freedom Fighter"]
    stance_label = stance_labels[stance] if stance < len(stance_labels) else "Unknown"

    return {
        "summary": summary,
        "predicted_stance": stance_label,
        "bias_score": bias_score
    }


# Streamlit UI
def main():
    st.set_page_config(page_title="OCR & Stance Analysis", page_icon="📝", layout="wide")
    
    st.title("OCR and Stance Analysis App")
    st.write("Upload an image containing text to analyze its stance and sentiment.")
    
    # File uploader
    uploaded_file = st.file_uploader("Choose an image file", type=["jpg", "jpeg", "png", "webp"])
    
    if uploaded_file is not None:
        # Display the uploaded image
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Image", use_column_width=True)
        
        # Process the image when user clicks the button
        if st.button("Process Image"):
            with st.spinner("Processing image... This may take a minute."):
                try:
                    # Save the uploaded file to a temporary file
                    with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as tmp_file:
                        tmp_file.write(uploaded_file.getvalue())
                        temp_path = tmp_file.name
                    
                    # Initialize OCR model and process the image
                    ocr_model = OCRTextModel()
                    formatted_text, detected_lang = ocr_model.process_image(temp_path)
                    
                    # Remove temporary file
                    os.unlink(temp_path)
                    
                    # Display the extracted text
                    st.subheader("Extracted Text:")
                    st.text_area("Text from Image", formatted_text, height=200)
                    
                    # Run stance analysis
                    model_path = "project/saved_models"
                    results = run_stance_analysis(model_path, formatted_text)
                    
                    # Display results
                    st.subheader("Analysis Results:")
                    
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Predicted Stance", results["predicted_stance"])
                    with col2:
                        bias_value = results["bias_score"]
                        st.metric("Bias Score", f"{bias_value:.2f}", 
                                 delta="Positive" if bias_value > 0 else "Negative" if bias_value < 0 else "Neutral")
                    with col3:
                        st.metric("Text Language", detected_lang.upper())
                    
                    st.subheader("Summary:")
                    st.write(results["summary"])
                    
                except Exception as e:
                    st.error(f"❌ Error processing the image: {str(e)}")


if __name__ == "__main__":
    main()
