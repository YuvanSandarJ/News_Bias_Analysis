# stance_summary_module.py

import os
import torch
import torch.nn as nn
import joblib
import numpy as np
from transformers import pipeline
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer


class StanceModel:
    def __init__(self, input_dim=4, output_dim=3, model_dir="D:/NLP/saved_models"):
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.model_dir = model_dir
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = None
        self.tfidf = None
        self.label_encoder = None

    def load(self):
        """Load the trained model, TF-IDF vectorizer, and label encoder."""
        # Load model
        self.model = nn.Sequential(
            nn.Linear(self.input_dim + 5000, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, self.output_dim),
            nn.Softmax(dim=1)
        ).to(self.device)

        self.model.load_state_dict(torch.load(
            os.path.join(self.model_dir, "stance_model.pt"),
            map_location=self.device
        ))

        # Load vectorizer and label encoder
        self.tfidf = joblib.load(os.path.join(self.model_dir, "tfidf_vectorizer.joblib"))
        self.label_encoder = joblib.load(os.path.join(self.model_dir, "label_encoder.joblib"))
        self.model.eval()

    def save(self):
        """Save the model weights and other components to disk."""
        torch.save(self.model.state_dict(), os.path.join(self.model_dir, "stance_model.pt"))
        joblib.dump(self.tfidf, os.path.join(self.model_dir, "tfidf_vectorizer.joblib"))
        joblib.dump(self.label_encoder, os.path.join(self.model_dir, "label_encoder.joblib"))

    def predict(self, features):
        """Predict stance based on input features."""
        with torch.no_grad():
            return self.model(features)


class StanceSummaryModel:
    def __init__(self, stance_model_dir, summarizer_model="facebook/bart-large-cnn"):
        self.stance_model = StanceModel(input_dim=4, output_dim=3, model_dir=stance_model_dir)
        self.stance_model.load()
        self.analyzer = SentimentIntensityAnalyzer()
        self.summarizer = pipeline("summarization", model=summarizer_model)

    def summarize_and_analyze(self, text):
        """Summarize the text and perform stance and sentiment analysis."""
        # Step 1: Summarize the input text
        summary = self.summarizer(text, max_length=150, min_length=50, do_sample=False)[0]['summary_text']

        # Step 2: Sentiment features using VADER
        sentiment_scores = self.analyzer.polarity_scores(summary)
        sentiment_features = np.array([
            sentiment_scores['neg'],
            sentiment_scores['neu'],
            sentiment_scores['pos'],
            sentiment_scores['compound']
        ]).reshape(1, -1)

        # Step 3: TF-IDF + Sentiment
        tfidf_features = self.stance_model.tfidf.transform([summary]).toarray()
        combined_features = np.hstack([tfidf_features, sentiment_features])

        # Step 4: Predict stance
        input_tensor = torch.tensor(combined_features, dtype=torch.float32).to(self.stance_model.device)
        output = self.stance_model.predict(input_tensor)
        stance_index = torch.argmax(output, dim=1).item()

        # Step 5: Bias score (compound sentiment)
        bias_score = sentiment_scores['compound']

        return summary, stance_index, bias_score


def run_stance_analysis(model_dir, text_file_path):
    """Load text from file, run stance and sentiment analysis, and return the results."""
    if not os.path.exists(text_file_path):
        raise FileNotFoundError(f"❌ File not found: {text_file_path}")

    with open(text_file_path, "r", encoding="utf-8") as file:
        input_text = file.read()

    stance_summary_model = StanceSummaryModel(stance_model_dir=model_dir)
    summary, stance, bias_score = stance_summary_model.summarize_and_analyze(input_text)

    stance_labels = ["Political", "Terrorist", "Freedom Fighter"]
    stance_label = stance_labels[stance] if stance < len(stance_labels) else "Unknown"

    return {
        "summary": summary,
        "predicted_stance": stance_label,
        "bias_score": bias_score
    }


import easyocr
from textblob import TextBlob
from langdetect import detect
from deep_translator import GoogleTranslator  # Importing from deep-translator
import torch
import pickle
import os

# Language mapping for EasyOCR (paired languages for compatibility)
LANGUAGE_MAPPING = {
    'fr': ['fr', 'en'],
    'ja': ['ja', 'en'], 
    'ko': ['ko', 'en'], 
    'ar': ['ar', 'en'],
    'ru': ['ru', 'en'],
    'it': ['it', 'en'],
    'pt': ['pt', 'en'],  
}

class OCRTextModel:
    def __init__(self, languages=None, use_gpu=True):
        if languages is None:
            languages = ['fr']  # Only French for OCR (adjust as needed)
        
        # Prepare a list of language pairs (combinations)
        self.language_pairs = [LANGUAGE_MAPPING[lang] for lang in languages if lang in LANGUAGE_MAPPING]
        
        # Initialize the translator
        self.translator = GoogleTranslator()

        # Initialize OCR model (PyTorch-based, easyocr uses PyTorch internally)
        self.reader = easyocr.Reader(['fr', 'en'], gpu=use_gpu)

    def process_image(self, image_path):
        # Read text from image by processing each language pair individually
        raw_text = ""
        for lang_pair in self.language_pairs:
            results = self.reader.readtext(image_path, detail=0)
            raw_text += " ".join(results) + " "

        if not raw_text.strip():
            raise ValueError("No text detected in image.")

        # Detect language (This should always detect French if the image is in French)
        detected_lang = detect(raw_text)
        print(f"🌐 Detected language code: {detected_lang}")

        # If detected language is French, translate it to English
        if detected_lang == 'fr':
            translated_text = self.translator.translate(raw_text, src='fr', target='en')
            print(f"🔵 Translated text:\n{translated_text}")
        else:
            translated_text = raw_text
            print(f"✅ Text is already in English.")

        # Correct grammar using TextBlob
        corrected_blob = TextBlob(translated_text).correct()
        formatted_text = "\n\n".join([str(sentence) for sentence in corrected_blob.sentences])  # Paragraphs separated by double newline

        return formatted_text, detected_lang

    def save_model_and_text(self, text, save_folder, base_filename):
        # Ensure the folder exists
        os.makedirs(save_folder, exist_ok=True)

        # Save the processed text to a .txt file
        text_path = os.path.join(save_folder, base_filename + ".txt")
        try:
            with open(text_path, "w", encoding="utf-8") as f:
                f.write(text)  # The formatted text with proper paragraph breaks
            print(f"✅ Text saved at: {text_path}")
        except Exception as e:
            print(f"❌ Error saving the text: {e}")

        # Save the OCR model as a .pt file (using torch)
        model_path = os.path.join(save_folder, base_filename + ".pt")
        try:
            torch.save(self.reader, model_path)  # Save the entire reader model (easyocr internal model)
            print(f"✅ Model saved at: {model_path}")
        except Exception as e:
            print(f"❌ Error saving the model: {e}")

    def load_model(self, model_path):
        try:
            reader = torch.load(model_path)
            return reader
        except Exception as e:
            print(f"❌ Error loading the model: {e}")
            return None



if __name__ == "__main__":
      # Initialize the OCRTextModel
    ocr_model = OCRTextModel()

    # Path to the image you want to process
    image_path = r"221501184/test2.jpg"  # Replace with your actual image path

    # Process the image
    try:
        formatted_text, detected_lang = ocr_model.process_image(image_path)

        # Define the new save folder and base filename
        save_folder = r"221501184"  # Changed save folder location
        base_filename = "processed_model"

        # Save the processed text and model
        ocr_model.save_model_and_text(formatted_text, save_folder, base_filename)
    except Exception as e:
        print(f"❌ Error processing the image: {e}")
        
    model_path = "project/saved_models"
    text_path = "221501184/processed_model.txt"
    
    try:
        results = run_stance_analysis(model_path, text_path)
        print("Summary:", results["summary"])
        print("Predicted Stance:", results["predicted_stance"])
        print("Bias Score:", results["bias_score"])
    except Exception as e:
        print(str(e))
