# main.py

import os
from nlp_part_1 import OCRTextModel
from summary import summarize_and_analyze

def main(image_path, model_dir, save_folder):
    try:
        # Step 1: Initialize the OCR model and process the image
        ocr_model = OCRTextModel()
        formatted_text, detected_lang = ocr_model.process_image(image_path)

        # Step 2: Save the OCR processed text to a file
        base_filename = "ocr_processed_text"
        ocr_model.save_model_and_text(formatted_text, save_folder, base_filename)

        # Step 3: Summarize the text and analyze stance
        summary, stance_label, bias_score = summarize_and_analyze(formatted_text, model_dir)

        # Step 4: Print results
        print("Summary:", summary)
        print("Predicted Stance:", stance_label)
        print("Bias Score:", bias_score)

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    # Define paths
    image_path = "D:/NLP/221501184/test2.jpg"  # Replace with your actual image path
    model_dir = "D:/NLP/saved_models"  # Directory where models are stored
    save_folder = "D:/NLP/221501184"  # Folder to save text and model

    # Run the integration
    main(image_path, model_dir, save_folder)
