import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import joblib
import numpy as np
import pandas as pd


class StanceModel:
    def __init__(self, model_dir="saved_models", batch_size=32, epochs=3, device=None):
        self.model_dir = model_dir
        self.analyzer = SentimentIntensityAnalyzer()
        self.model = None
        self.tfidf = None
        self.label_encoder = None
        self.batch_size = batch_size
        self.epochs = epochs
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')

    def load_data(self, file_path):
        for encoding in ['utf-8', 'latin1']:
            try:
                return pd.read_csv(file_path,
                                   sep='\t',
                                   encoding=encoding,
                                   engine='python',
                                   on_bad_lines='skip',
                                   names=['label', 'text'],
                                   header=None)
            except Exception:
                continue
        raise ValueError(f"❌ Could not load file: {file_path}")

    def preprocess(self, df):
        df = df.dropna(subset=['text', 'label'])
        texts = df['text'].astype(str).str.strip()
        labels = df['label'].astype(str).str.strip()
        labels = labels[labels != 'label']  # Remove accidental header rows
        texts = texts[labels.index]
        return texts, labels

    def extract_sentiment(self, texts):
        features = []
        for text in texts:
            try:
                sentiment = self.analyzer.polarity_scores(text)
                features.append([sentiment['neg'], sentiment['neu'], sentiment['pos'], sentiment['compound']])
            except:
                features.append([0, 1.0, 0, 0])  # Neutral fallback
        return np.array(features)

    def fit(self, train_df):
        texts, labels = self.preprocess(train_df)
        sentiment_features = self.extract_sentiment(texts)

        self.tfidf = TfidfVectorizer(max_features=5000, ngram_range=(1, 2), stop_words='english')
        tfidf_features = self.tfidf.fit_transform(texts)

        self.label_encoder = LabelEncoder()
        labels_encoded = self.label_encoder.fit_transform(labels)

        X = np.hstack([tfidf_features.toarray(), sentiment_features])
        y = labels_encoded

        X_tensor = torch.tensor(X, dtype=torch.float32)
        y_tensor = torch.tensor(y, dtype=torch.long)

        train_data = TensorDataset(X_tensor, y_tensor)
        train_loader = DataLoader(train_data, batch_size=self.batch_size, shuffle=True)

        self.model = nn.Sequential(
            nn.Linear(X_tensor.shape[1], 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, len(np.unique(y))),
            nn.Softmax(dim=1)
        ).to(self.device)

        optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        criterion = nn.CrossEntropyLoss()

        for epoch in range(self.epochs):
            self.model.train()
            running_loss = 0.0
            all_preds = []
            all_labels = []
            correct_predictions = 0
            total_predictions = 0

            for batch in train_loader:
                X_batch, y_batch = batch
                X_batch, y_batch = X_batch.to(self.device), y_batch.to(self.device)

                optimizer.zero_grad()                          # Step 1: Zero old gradients
                outputs = self.model(X_batch)                  # Step 2: Forward pass
                loss = criterion(outputs, y_batch)             # Step 3: Compute loss
                loss.backward()                                # Step 4: Backpropagation
                optimizer.step()                               # Step 5: Update weights

                # Optional: print gradients
                # for name, param in self.model.named_parameters():
                #     if param.requires_grad:
                #         print(f"{name} gradient: {param.grad.norm()}")

                running_loss += loss.item()
                _, predicted = torch.max(outputs, 1)
                all_preds.extend(predicted.cpu().numpy())
                all_labels.extend(y_batch.cpu().numpy())
                correct_predictions += (predicted == y_batch).sum().item()
                total_predictions += y_batch.size(0)

            accuracy = correct_predictions / total_predictions * 100
            print(f"Epoch {epoch + 1}/{self.epochs} - Loss: {running_loss:.4f} - Accuracy: {accuracy:.2f}%")
            print("Classification Report:")
            print(classification_report(all_labels, all_preds, target_names=self.label_encoder.classes_))

        self.save()

    def evaluate(self, test_df):
        texts, labels = self.preprocess(test_df)
        sentiment_features = self.extract_sentiment(texts)
        tfidf_features = self.tfidf.transform(texts)

        labels_encoded = self.label_encoder.transform(labels)
        X = np.hstack([tfidf_features.toarray(), sentiment_features])
        X_tensor = torch.tensor(X, dtype=torch.float32).to(self.device)

        self.model.eval()
        with torch.no_grad():
            outputs = self.model(X_tensor)
            _, predicted = torch.max(outputs, 1)
            print("Evaluation Report:")
            print(classification_report(labels_encoded, predicted.cpu(), target_names=self.label_encoder.classes_))

    def save(self):
        os.makedirs(self.model_dir, exist_ok=True)
        torch.save(self.model.state_dict(), os.path.join(self.model_dir, "stance_model.pt"))
        joblib.dump(self.tfidf, os.path.join(self.model_dir, "tfidf_vectorizer.joblib"))
        joblib.dump(self.label_encoder, os.path.join(self.model_dir, "label_encoder.joblib"))
        print(f"✅ Model and components saved to: {self.model_dir}")

    def load(self):
        self.model = nn.Sequential(
            nn.Linear(5000 + 4, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, 3),  # Adjust this if you have a different number of classes
            nn.Softmax(dim=1)
        ).to(self.device)
        self.model.load_state_dict(torch.load(os.path.join(self.model_dir, "stance_model.pt"), map_location=self.device))
        self.tfidf = joblib.load(os.path.join(self.model_dir, "tfidf_vectorizer.joblib"))
        self.label_encoder = joblib.load(os.path.join(self.model_dir, "label_encoder.joblib"))
        self.model.eval()

    def predict(self, text):
        if self.model is None or self.tfidf is None:
            self.load()
        sentiment = self.analyzer.polarity_scores(str(text).strip())
        sentiment_features = [[sentiment['neg'], sentiment['neu'], sentiment['pos'], sentiment['compound']]]
        tfidf_features = self.tfidf.transform([text]).toarray()
        X = np.hstack([tfidf_features, sentiment_features])
        X_tensor = torch.tensor(X, dtype=torch.float32).to(self.device)
        output = self.model(X_tensor)
        _, predicted = torch.max(output, 1)
        return self.label_encoder.inverse_transform([predicted.item()])[0]


# === USAGE ===

# Initialize model
model = StanceModel(model_dir="D:/NLP/saved_models", batch_size=32, epochs=20)

# Load and train on training data
train_data = model.load_data("D:/NLP/new/semeval-2017-train.csv")
model.fit(train_data)

# Evaluate on test data
test_data = model.load_data("D:/NLP/new/semeval-2017-test.csv")
model.evaluate(test_data)

# Predict an example
sample_text = "The new policy is absolutely good for our country!"
prediction = model.predict(sample_text)
print(f"Predicted stance for the text: {prediction}")
