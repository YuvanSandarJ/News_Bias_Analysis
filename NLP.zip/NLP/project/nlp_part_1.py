import easyocr
from textblob import TextBlob
from langdetect import detect
from deep_translator import GoogleTranslator  # Importing from deep-translator
import torch
import pickle
import os

# Language mapping for EasyOCR (paired languages for compatibility)
LANGUAGE_MAPPING = {
    'fr': ['fr', 'en'],
    'ja': ['ja', 'en'], 
    'ko': ['ko', 'en'], 
    'ar': ['ar', 'en'],
    'ru': ['ru', 'en'],
    'it': ['it', 'en'],
    'pt': ['pt', 'en'],  
}

class OCRTextModel:
    def __init__(self, languages=None, use_gpu=True):
        if languages is None:
            languages = ['fr']  # Only French for OCR (adjust as needed)
        
        # Prepare a list of language pairs (combinations)
        self.language_pairs = [LANGUAGE_MAPPING[lang] for lang in languages if lang in LANGUAGE_MAPPING]
        
        # Initialize the translator
        self.translator = GoogleTranslator()

        # Initialize OCR model (PyTorch-based, easyocr uses PyTorch internally)
        self.reader = easyocr.Reader(['fr', 'en'], gpu=use_gpu)

    def process_image(self, image_path):
        # Read text from image by processing each language pair individually
        raw_text = ""
        for lang_pair in self.language_pairs:
            results = self.reader.readtext(image_path, detail=0)
            raw_text += " ".join(results) + " "

        if not raw_text.strip():
            raise ValueError("No text detected in image.")

        # Detect language (This should always detect French if the image is in French)
        detected_lang = detect(raw_text)
        print(f"🌐 Detected language code: {detected_lang}")

        # If detected language is French, translate it to English
        if detected_lang == 'fr':
            translated_text = self.translator.translate(raw_text, src='fr', target='en')
            print(f"🔵 Translated text:\n{translated_text}")
        else:
            translated_text = raw_text
            print(f"✅ Text is already in English.")

        # Correct grammar using TextBlob
        corrected_blob = TextBlob(translated_text).correct()
        formatted_text = "\n\n".join([str(sentence) for sentence in corrected_blob.sentences])  # Paragraphs separated by double newline

        return formatted_text, detected_lang

    def save_model_and_text(self, text, save_folder, base_filename):
        # Ensure the folder exists
        os.makedirs(save_folder, exist_ok=True)

        # Save the processed text to a .txt file
        text_path = os.path.join(save_folder, base_filename + ".txt")
        try:
            with open(text_path, "w", encoding="utf-8") as f:
                f.write(text)  # The formatted text with proper paragraph breaks
            print(f"✅ Text saved at: {text_path}")
        except Exception as e:
            print(f"❌ Error saving the text: {e}")

        # Save the OCR model as a .pt file (using torch)
        model_path = os.path.join(save_folder, base_filename + ".pt")
        try:
            torch.save(self.reader, model_path)  # Save the entire reader model (easyocr internal model)
            print(f"✅ Model saved at: {model_path}")
        except Exception as e:
            print(f"❌ Error saving the model: {e}")

    def load_model(self, model_path):
        try:
            reader = torch.load(model_path)
            return reader
        except Exception as e:
            print(f"❌ Error loading the model: {e}")
            return None

# Example Usage
if __name__ == "__main__":
    # Initialize the OCRTextModel
    ocr_model = OCRTextModel()

    # Path to the image you want to process
    image_path = r"D:/NLP/221501184/test2.jpg"  # Replace with your actual image path

    # Process the image
    try:
        formatted_text, detected_lang = ocr_model.process_image(image_path)

        # Define the new save folder and base filename
        save_folder = r"D:\NLP\221501184"  # Changed save folder location
        base_filename = "processed_model"

        # Save the processed text and model
        ocr_model.save_model_and_text(formatted_text, save_folder, base_filename)
    except Exception as e:
        print(f"❌ Error processing the image: {e}")